﻿using System;

namespace D13
{
    internal class D13srt
    {
        static void Main(string[] args)
        {

        }
    }
}
