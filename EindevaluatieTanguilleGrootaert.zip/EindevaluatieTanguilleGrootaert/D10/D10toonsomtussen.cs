﻿using System;

namespace D10
{
    internal class D10toonsomtussen
    {
        static void Main(string[] args)
        {
            ToonSomTussen(0, 10);

            static void ToonSomTussen(int min, int max)
            {                
                Console.WriteLine(max - min);
            }
        }
    }
}
