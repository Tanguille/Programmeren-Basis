﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D17
{
    internal class D17telefoonboek
    {
        static void Main(string[] args)
        {
            //zie "PhoneDirectory.cs" voor de klasse die bij deze oefening hoort.
        }
    }
}
