﻿using System;
using System.Collections.Generic;

namespace D17
{
    internal class D17frequentie
    {
        static void Main(string[] args)
        {
            Dictionary<char, int> woordFrequentie = new Dictionary<char, int>();

            Console.Write("Geef een tekst: ");
            string input = Console.ReadLine();

            foreach (char c in input)
            {
                //Dictionary[c] = c;
            }
        }
    }
}
