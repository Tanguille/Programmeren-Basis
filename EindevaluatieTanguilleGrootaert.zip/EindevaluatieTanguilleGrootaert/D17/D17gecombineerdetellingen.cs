﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D17
{
    internal class D17gecombineerdetellingen
    {
        static void Main(string[] args)
        {

        }
    }
}
