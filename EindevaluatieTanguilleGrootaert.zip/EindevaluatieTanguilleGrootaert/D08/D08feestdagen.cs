﻿using System;

namespace D08 {
    class D08feestdagen {
        static void Main(string[] args) {
            string[] feestdagen = new string[12];
            feestdagen[0] = "Nieuwjaar";
            feestdagen[1] = "Pasen";
            feestdagen[2] = "Paasmaandag";
            feestdagen[3] = "Dag vd Arbeid";
            feestdagen[4] = "OLH Hemelvaart";
            feestdagen[5] = "Pinksteren";
            feestdagen[6] = "Pinkstermaandag";
            feestdagen[7] = "Nationale Feestdag";
            feestdagen[8] = "OLV Hemelvaart";
            feestdagen[9] = "Allerheiligen";
            feestdagen[10] = "Wapenstilstand";
            feestdagen[11] = "Kerstdag";

            Console.WriteLine(feestdagen.Length);
        }
    }
}
