﻿using System.Drawing;

namespace Domain {

    public interface Figure {

        public void Draw(Graphics gfx);

    }
}
